import React from 'react'
export default function App() {
  return <h1 className='text-2xl font-bold text-center mt-10'>Creador de Resultados de Aprendizaje</h1>
}